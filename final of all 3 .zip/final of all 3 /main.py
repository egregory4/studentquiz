from tkinter import *
import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
from tkinter.messagebox import showinfo
import subprocess
from tkinter import messagebox
from PIL.ImageWin import Window


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.geometry('800x800')
        self.title('Student Help Login')
        # place a button on the root window
        self.configure(background='#938beb')
        self.image = Image.open('applogo.png')
        self.python_image = ImageTk.PhotoImage(self.image)
        ttk.Label(self, image=self.python_image).pack()
        Label(self, text="Welcome to our online student feedback quiz where you as students can report express\n"
                         " your voice and make an impact in school by bring any issues up through this quiz anonymously.",font=("arial italic", 18)).pack()
        Label(self, text="Our goal is to create a place where a schools student to feel safe to express their thoughts and \n"
                         "feeling anonymously, not seeing the students as individuals but as a whole and what changes to \n"
                         "teachers and staff can change to help all the students whether its big or small. We have found\n"
                         " through our surveys that two thirds of students reported an increase in supporting others with\n"
                         " their mental wellness and also that 78% of students feel optimistic or hopeful about\n"
                         " their school related goals and future job prospects.", font=("arial italic", 18)).pack()
        # store email address and password
        username = tk.StringVar()
        password = tk.StringVar()
        year = tk.StringVar()
        def login_clicked():
            msg = f'You entered name: {username.get()} and password: {password.get()} and year: {year.get()}'
            showinfo(
                title='Information',
                message=msg
            )

        def fun1():
            username = "ella13"
            password = "boo"
            year = "13"
            if username_entry.get() == username and password_entry.get() == password:
                messagebox.showinfo(title="Login Success", message="You successfully logged in.")
            else:
                messagebox.showerror(title="Error", message="Invalid login.")

        def fun2():
            subprocess.call(["python", "studentquestionfile.py"])
        # Sign in frame
        signin = ttk.Frame(self)
        signin.pack(padx=10, pady=10, fill='x', expand=True)
        # email
        username_label = ttk.Label(signin, text="Username:")
        username_label.pack(fill='x', expand=True)
        username_entry = ttk.Entry(signin, textvariable=username)
        username_entry.pack(fill='x', expand=True)
        username_entry.focus()
        # password
        password_label = ttk.Label(signin, text="Password:")
        password_label.pack(fill='x', expand=True)
        password_entry = ttk.Entry(signin, textvariable=password, show="*")
        password_entry.pack(fill='x', expand=True)
        # year
        year_label = ttk.Label(signin, text="Year:")
        year_label.pack(fill='x', expand=True)
        year_entry = ttk.Entry(signin, textvariable=year)
        year_entry.pack(fill='x', expand=True)
        b=ttk.Button(signin, text="start", command=lambda: [fun1(), fun2()])
        b.pack()

    def open_window(self):
        window = Window(self)
        window.grab_set()


if __name__ == "__main__":
    print("--")
    app = App()
    app.mainloop()

